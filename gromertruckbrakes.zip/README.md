# GROMER Truck Brakes

Sitio web de presentación de tambores y mazas de freno para camión.

## Setup

1. Instala dependencias:
   ```
   npm install
   ```
2. Levanta el entorno de desarrollo:
   ```
   npm run dev
   ```
3. Construye el proyecto:
   ```
   npm run build
   ```
4. Inicia en producción:
   ```
   npm start
   ```

## Despliegue

Se recomienda desplegar en Vercel siguiendo la integración con GitHub.
